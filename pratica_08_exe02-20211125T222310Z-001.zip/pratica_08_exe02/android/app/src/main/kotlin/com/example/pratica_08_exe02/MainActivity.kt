package com.example.pratica_08_exe02

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
