package com.example.pratica_08

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
