package com.example.pratica_12

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
