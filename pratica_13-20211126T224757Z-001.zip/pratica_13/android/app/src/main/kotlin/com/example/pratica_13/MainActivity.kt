package com.example.pratica_13

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
