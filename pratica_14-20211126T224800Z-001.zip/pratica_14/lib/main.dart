import 'package:flutter/material.dart';
import 'package:pratica_14/rota/tela/tela.dart';
import 'package:pratica_14/rota/tela/rota.dart';

void main() => runApp(
      MaterialApp(
        initialRoute: '/',
        routes: {
          '/': (context) => PrimeiraTela(),
          '/segunda': (context) => SegundaTela(),
          '/terceira': (context) => TerceiraTela(),
        },
      ),
    );
