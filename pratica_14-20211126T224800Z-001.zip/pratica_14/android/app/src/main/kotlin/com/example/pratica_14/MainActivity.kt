package com.example.pratica_14

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
