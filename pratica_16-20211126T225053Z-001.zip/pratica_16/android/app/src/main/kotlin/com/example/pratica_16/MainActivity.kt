package com.example.pratica_16

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
